# CS61A Ants Project

In this project, I created a game that is similar to Plants vs. Zombies (Ants vs. Somebees). I edited different classes of ants that have different abilities, such as ThrowerAnts and the QueenAnt, and worked on applying different status effects to the ants such as slows and stuns.